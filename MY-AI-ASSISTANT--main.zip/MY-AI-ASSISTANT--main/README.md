# MY-AI-ASSISTANT-
AI ASSISTANT made in Python this Project inspired by Alexa this project is able to perform task Save Files, Shut down System, Open Folder, Open Program ,send Email, Search in Wikipedia, play music on YouTube, search data From Google , send WhatsApp massage etc.



https://github.com/user-attachments/assets/f633363b-8921-43d8-9f66-0a04bb89c291



https://github.com/user-attachments/assets/51cc54ba-049b-4275-a3d1-58da0e661fe9



